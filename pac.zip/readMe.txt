Names and Id's:
Tomer Malovani 208375436 
Gal Kontente 207002015

1. The player can choose if they want to play a colorfull game or not.

2. During the game, if the player press ESC he has an option to exit the game.