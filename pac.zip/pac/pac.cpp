#include <windows.h>
#include <iostream>
using namespace std;

#include "./Game.h"

int main() {
	Game game;
	game.gameFlow();
	return 0;
}