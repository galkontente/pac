#include "Creature.h"

//bool Creature::canMove(int dir, Point coor) {  // a general canmove func- checks the borders of the board- NEED TO CHANGE$$$$$$$$$$$$$
//    int x = coor.getX();
//    int y = coor.getY();
//    switch (dir) {
//    case 0: // UP
//        if (y <= 1) {
//            return false;
//        }
//
//        else return true;
//        break;
//    case 1: // DOWN
//
//        if (y >= 23) {
//            return false;
//        }
//
//        else return true;
//        break;
//    case 2: // LEFT
//        if (x <= 1) {
//            return false;
//        }
//        else return true;
//        break;
//    case 3: // RIGHT
//
//        if (x >= 78) {
//            return false;
//        }
//
//        else return true;
//        break;
//    }
//
//    return false;
//}